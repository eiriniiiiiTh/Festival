package com.festival.service;

import com.festival.model.Festival;
import com.festival.model.FestivalStatus;
import com.festival.model.User;
import com.festival.repository.FestivalRepository;
import com.festival.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class FestivalService {

    private final FestivalRepository festivalRepository;
    private final UserRepository userRepository;

    @Autowired
    public FestivalService(FestivalRepository festivalRepository, UserRepository userRepository) {
        this.festivalRepository = festivalRepository;
        this.userRepository = userRepository;
    }

    public Festival createFestival(Festival festival) {
        return festivalRepository.save(festival);
    }

    public List<Festival> getAllFestivals() {
        return festivalRepository.findAll();
    }

    public Festival getFestivalById(Long id) {
        return festivalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Το φεστιβάλ με ID " + id + " δεν βρέθηκε"));
    }

    public Festival updateFestival(Long id, Festival updatedFestival) {
        Festival existing = getFestivalById(id);

        existing.setName(updatedFestival.getName());
        existing.setDescription(updatedFestival.getDescription());
        existing.setLocation(updatedFestival.getLocation());
        existing.setDate(updatedFestival.getDate());
        existing.setStatus(updatedFestival.getStatus());

        if (updatedFestival.getVenueLayout() != null) {
            existing.setVenueLayout(updatedFestival.getVenueLayout());
        }

        if (updatedFestival.getBudget() != null) {
            existing.setBudget(updatedFestival.getBudget());
        }

        if (updatedFestival.getVendorManagement() != null) {
            existing.setVendorManagement(updatedFestival.getVendorManagement());
        }

        if (updatedFestival.getOrganizers() != null) {
            existing.setOrganizers(updatedFestival.getOrganizers());
        }

        return festivalRepository.save(existing);
    }

    public void deleteFestival(Long id) {
        if (!festivalRepository.existsById(id)) {
            throw new RuntimeException("Το φεστιβάλ με ID " + id + " δεν βρέθηκε");
        }
        festivalRepository.deleteById(id);
    }

    public Festival changeFestivalStatus(Long id, FestivalStatus newStatus) {
        if (newStatus == null) {
            throw new IllegalArgumentException("Η νέα κατάσταση δεν μπορεί να είναι κενή");
        }

        Festival festival = getFestivalById(id);
        festival.setStatus(newStatus);
        return festivalRepository.save(festival);
    }

    public List<Festival> searchFestivals(String name, String description, String location,
                                          LocalDate startDate, LocalDate endDate, FestivalStatus status) {
        return festivalRepository.searchFestivals(name, description, location, startDate, endDate, status);
    }

    public List<Festival> getFestivalsByOrganizer(User organizer) {
        return festivalRepository.findByOrganizersContaining(organizer);
    }

    public List<Festival> getFestivalsByStatus(FestivalStatus status) {
        return festivalRepository.findByStatus(status);
    }

    public List<Festival> searchByName(String name) {
        return festivalRepository.findByNameContainingIgnoreCase(name);
    }

    public List<Festival> searchByLocation(String location) {
        return festivalRepository.findByLocationContainingIgnoreCase(location);
    }
}
