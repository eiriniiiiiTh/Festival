package com.festival.service;

import com.festival.exception.UserNotFoundException;
import com.festival.model.User;
import com.festival.model.UserRole;
import com.festival.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository repository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    
    public User createUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return repository.save(user);
    }

    
    public User updateUser(Long id, User updatedUser) {
        return repository.findById(id)
            .map(existing -> {
                existing.setName(updatedUser.getName());
                existing.setEmail(updatedUser.getEmail());
                existing.setUsername(updatedUser.getUsername());
                existing.setRole(updatedUser.getRole());

                if (updatedUser.getPassword() != null && !updatedUser.getPassword().isBlank()) {
                    existing.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
                }

                return repository.save(existing);
            })
            .orElseThrow(() -> new UserNotFoundException(id));
    }

    
    public User getUserById(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new UserNotFoundException(id));
    }

    
    public User getUserByUsername(String username) {
        return repository.findByUsername(username)
            .orElseThrow(() -> new UserNotFoundException("Username: " + username));
    }

    
    public User getUserByEmail(String email) {
        return repository.findByEmail(email)
            .orElseThrow(() -> new UserNotFoundException("Email: " + email));
    }

    
    public List<User> searchByName(String name) {
        return repository.findByNameContainingIgnoreCase(name);
    }

   
    public List<User> getUsersByRole(UserRole role) {
        return repository.findByRole(role);
    }

    
    public List<User> getAllUsers() {
        return repository.findAll();
    }

    
    public boolean existsById(Long id) {
        return repository.existsById(id);
    }

    
    public void deleteUser(Long id) {
        if (!repository.existsById(id)) {
            throw new UserNotFoundException(id);
        }
        repository.deleteById(id);
    }

   
    public boolean authenticateUser(String username, String rawPassword) {
        User user = getUserByUsername(username);
        return passwordEncoder.matches(rawPassword, user.getPassword());
    }
}
