package com.festival.service;

import com.festival.exception.PerformanceNotFoundException;
import com.festival.model.Festival;
import com.festival.model.Performance;
import com.festival.model.PerformanceStatus;
import com.festival.model.User;
import com.festival.repository.FestivalRepository;
import com.festival.repository.PerformanceRepository;
import com.festival.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class PerformanceService {

    private final PerformanceRepository repository;
    private final FestivalRepository festivalRepository;
    private final UserRepository userRepository;

    public PerformanceService(PerformanceRepository repository,
                              FestivalRepository festivalRepository,
                              UserRepository userRepository) {
        this.repository = repository;
        this.festivalRepository = festivalRepository;
        this.userRepository = userRepository;
    }

    public List<Performance> getAllPerformances() {
        return repository.findAll();
    }

    public Optional<Performance> getPerformanceById(Long id) {
        return repository.findById(id);
    }

    public Performance createPerformance(Performance performance) {
        if (performance.getFestival() == null || performance.getFestival().getId() == null) {
            throw new IllegalArgumentException("Το φεστιβάλ είναι υποχρεωτικό");
        }
        if (performance.getAssignedStaff() == null || performance.getAssignedStaff().getId() == null) {
            throw new IllegalArgumentException("Το προσωπικό είναι υποχρεωτικό");
        }

        Festival existingFestival = festivalRepository.findById(performance.getFestival().getId())
                .orElseThrow(() -> new IllegalArgumentException("Το φεστιβάλ δεν υπάρχει"));

        User existingStaff = userRepository.findById(performance.getAssignedStaff().getId())
                .orElseThrow(() -> new IllegalArgumentException("Ο χρήστης δεν υπάρχει"));

        performance.setFestival(existingFestival);
        performance.setAssignedStaff(existingStaff);

        if (performance.getSetlist() == null) performance.setSetlist(Collections.emptyList());
        if (performance.getMerchandiseItems() == null) performance.setMerchandiseItems(Collections.emptyList());
        if (performance.getPreferredRehearsalTimes() == null) performance.setPreferredRehearsalTimes(Collections.emptyList());
        if (performance.getPreferredPerformanceSlots() == null) performance.setPreferredPerformanceSlots(Collections.emptyList());

        performance.setStatus(PerformanceStatus.CREATED);
        return repository.save(performance);
    }

    public Performance updatePerformance(Long id, Performance updated) {
        Performance existing = repository.findById(id)
                .orElseThrow(() -> new PerformanceNotFoundException(id));

        existing.setName(updated.getName());
        existing.setDescription(updated.getDescription());
        existing.setGenre(updated.getGenre());
        existing.setDuration(updated.getDuration());
        existing.setArtists(updated.getArtists());
        existing.setLocation(updated.getLocation());
        existing.setDate(updated.getDate());
        existing.setFestival(updated.getFestival());
        existing.setTechnicalRequirements(updated.getTechnicalRequirements());
        existing.setSetlist(updated.getSetlist() != null ? updated.getSetlist() : Collections.emptyList());
        existing.setMerchandiseItems(updated.getMerchandiseItems() != null ? updated.getMerchandiseItems() : Collections.emptyList());
        existing.setPreferredRehearsalTimes(updated.getPreferredRehearsalTimes() != null ? updated.getPreferredRehearsalTimes() : Collections.emptyList());
        existing.setPreferredPerformanceSlots(updated.getPreferredPerformanceSlots() != null ? updated.getPreferredPerformanceSlots() : Collections.emptyList());
        existing.setAssignedStaff(updated.getAssignedStaff());
        existing.setReviewScore(updated.getReviewScore());
        existing.setReviewComments(updated.getReviewComments());
        existing.setRejectionReason(updated.getRejectionReason());

        return repository.save(existing);
    }

    public void deletePerformance(Long id) {
        Performance performance = repository.findById(id)
                .orElseThrow(() -> new PerformanceNotFoundException(id));

        if (performance.getStatus() != PerformanceStatus.CREATED) {
            throw new IllegalStateException("Η εμφάνιση μπορεί να διαγραφεί μόνο όταν είναι σε κατάσταση CREATED");
        }

        repository.delete(performance);
    }

    public List<Performance> searchByName(String name) {
        return repository.findByNameContainingIgnoreCase(name);
    }

    public List<Performance> searchByGenre(String genre) {
        return repository.findByGenreIgnoreCase(genre);
    }

    public List<Performance> searchByArtistUsername(String username) {
        return repository.findByArtistUsernameContainingIgnoreCase(username);
    }

    public List<Performance> searchByFestivalId(Long festivalId) {
        return repository.findByFestivalId(festivalId);
    }

    public List<Performance> searchByStatus(PerformanceStatus status) {
        return repository.findByStatus(status);
    }

    public List<Performance> searchByLocation(String location) {
        return repository.findByLocationContainingIgnoreCase(location);
    }

    public List<Performance> getPerformancesByDate(LocalDate date) {
        return repository.findByDate(date);
    }

    public List<Performance> searchPerformances(String name, String genre, String artistUsername,
                                                Long festivalId, PerformanceStatus status) {
        if (name != null) return searchByName(name);
        if (genre != null) return searchByGenre(genre);
        if (artistUsername != null) return searchByArtistUsername(artistUsername);
        if (festivalId != null) return searchByFestivalId(festivalId);
        if (status != null) return searchByStatus(status);
        return getAllPerformances();
    }

    public Performance changePerformanceStatus(Long id, PerformanceStatus newStatus) {
        Performance performance = repository.findById(id)
                .orElseThrow(() -> new PerformanceNotFoundException(id));

        if (newStatus == null) {
            throw new IllegalArgumentException("Η νέα κατάσταση δεν μπορεί να είναι κενή");
        }

        PerformanceStatus current = performance.getStatus();

        boolean isValid = switch (current) {
            case CREATED -> newStatus == PerformanceStatus.SUBMITTED;
            case SUBMITTED -> newStatus == PerformanceStatus.REVIEWED;
            case REVIEWED -> newStatus == PerformanceStatus.APPROVED || newStatus == PerformanceStatus.REJECTED;
            case APPROVED -> newStatus == PerformanceStatus.SCHEDULED;
            default -> false;
        };

        if (!isValid) {
            throw new IllegalStateException("Μη έγκυρη μετάβαση από " + current + " σε " + newStatus);
        }

        if (newStatus == PerformanceStatus.SUBMITTED && !performance.isReadyForSubmission()) {
            throw new IllegalStateException("Η εμφάνιση δεν είναι έτοιμη για υποβολή");
        }

        performance.setStatus(newStatus);
        return repository.save(performance);
    }

    public boolean existsById(Long id) {
        return repository.existsById(id);
    }
}
