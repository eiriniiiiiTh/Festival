package com.festival.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Το όνομα είναι υποχρεωτικό")
    @Size(min = 2, max = 50, message = "Το όνομα πρέπει να έχει από 2 έως 50 χαρακτήρες")
    @Column(length = 50, nullable = false)
    private String name;

    @Email(message = "Το email δεν είναι έγκυρο")
    @NotBlank(message = "Το email είναι υποχρεωτικό")
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank(message = "Το username είναι υποχρεωτικό")
    @Size(min = 4, max = 30, message = "Το username πρέπει να έχει από 4 έως 30 χαρακτήρες")
    @Column(unique = true, nullable = false, length = 30)
    private String username;

    @NotBlank(message = "Ο κωδικός είναι υποχρεωτικός")
    @Size(min = 6, message = "Ο κωδικός πρέπει να έχει τουλάχιστον 6 χαρακτήρες")
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role = UserRole.VISITOR;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    @ManyToMany(mappedBy = "artists", fetch = FetchType.LAZY)
    @JsonIgnoreProperties("artists")
    private List<Performance> performances = new ArrayList<>();

    @ManyToMany(mappedBy = "organizers", fetch = FetchType.LAZY)
    @JsonIgnoreProperties("organizers")
    private List<Festival> festivals = new ArrayList<>();

    public User() {}

    public User(String name, String email, String username, String password, UserRole role) {
        this.name = name;
        this.email = email;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public UserRole getRole() { return role; }
    public void setRole(UserRole role) { this.role = role; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public List<Performance> getPerformances() { return performances; }
    public void setPerformances(List<Performance> performances) { this.performances = performances; }

    public List<Festival> getFestivals() { return festivals; }
    public void setFestivals(List<Festival> festivals) { this.festivals = festivals; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return id != null && id.equals(user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", role=" + role +
                '}';
    }
}
