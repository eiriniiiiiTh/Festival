package com.festival.model;

public enum UserRole {
    VISITOR,     
    ARTIST,      
    STAFF,       
    ORGANIZER    
}
