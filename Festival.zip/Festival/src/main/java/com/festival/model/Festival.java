package com.festival.model;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "festivals")
public class Festival {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 2, max = 100)
    @Column(length = 100, nullable = false, unique = true)
    private String name;

    @NotBlank
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;

    @NotBlank
    @Size(min = 2, max = 100)
    @Column(length = 100, nullable = false)
    private String location;

    @FutureOrPresent
    @Column(nullable = false)
    private LocalDate date;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FestivalStatus status = FestivalStatus.CREATED;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinTable(
        name = "festival_organizers",
        joinColumns = @JoinColumn(name = "festival_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    @Valid
    private List<User> organizers = new ArrayList<>();

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinTable(
        name = "festival_staff",
        joinColumns = @JoinColumn(name = "festival_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<User> staff = new ArrayList<>();

    @OneToMany(mappedBy = "festival", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Performance> performances = new ArrayList<>();

    @Embedded
    @Valid
    @AttributeOverrides({
        @AttributeOverride(name = "numberOfStages", column = @Column(name = "NUMBER_OF_STAGES")),
        @AttributeOverride(name = "vendorAreaCount", column = @Column(name = "VENDOR_AREA_COUNT")),
        @AttributeOverride(name = "hasFacilities", column = @Column(name = "HAS_FACILITIES"))
    })
    private VenueLayout venueLayout = new VenueLayout();

    @Embedded
    @Valid
    @AttributeOverrides({
        @AttributeOverride(name = "totalBudget", column = @Column(name = "TOTAL_BUDGET")),
        @AttributeOverride(name = "performanceCosts", column = @Column(name = "PERFORMANCE_COSTS")),
        @AttributeOverride(name = "logisticsCosts", column = @Column(name = "LOGISTICS_COSTS")),
        @AttributeOverride(name = "expectedRevenue", column = @Column(name = "EXPECTED_REVENUE"))
    })
    private Budget budget = new Budget();

    @Embedded
    @Valid
    @AttributeOverrides({
        @AttributeOverride(name = "foodStalls", column = @Column(name = "FOOD_STALLS")),
        @AttributeOverride(name = "merchandiseBooths", column = @Column(name = "MERCHANDISE_BOOTHS"))
    })
    private VendorManagement vendorManagement = new VendorManagement();

    public Festival() {}

    public Festival(String name, String description, String location, LocalDate date) {
        this.name = name;
        this.description = description;
        this.location = location;
        this.date = date;
        this.status = FestivalStatus.CREATED;
    }

    // Auto-calculate totalBudget
    @PrePersist
    @PreUpdate
    public void calculateBudget() {
        if (budget != null && budget.getLogisticsCosts() != null && budget.getPerformanceCosts() != null) {
            budget.setTotalBudget(budget.getLogisticsCosts() + budget.getPerformanceCosts());
        }
    }

    // Getters & Setters
    public Long getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public FestivalStatus getStatus() { return status; }
    public void setStatus(FestivalStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    public List<User> getOrganizers() { return organizers; }
    public void setOrganizers(List<User> organizers) { this.organizers = organizers; }

    public List<User> getStaff() { return staff; }
    public void setStaff(List<User> staff) { this.staff = staff; }

    public List<Performance> getPerformances() { return performances; }
    public void setPerformances(List<Performance> performances) { this.performances = performances; }

    public VenueLayout getVenueLayout() { return venueLayout; }
    public void setVenueLayout(VenueLayout venueLayout) { this.venueLayout = venueLayout; }

    public Budget getBudget() { return budget; }
    public void setBudget(Budget budget) { this.budget = budget; }

    public VendorManagement getVendorManagement() { return vendorManagement; }
    public void setVendorManagement(VendorManagement vendorManagement) { this.vendorManagement = vendorManagement; }

    public void addPerformance(Performance performance) {
        performances.add(performance);
        performance.setFestival(this);
    }

    public void removePerformance(Performance performance) {
        performances.remove(performance);
        performance.setFestival(null);
    }

    @Override
    public String toString() {
        return "Festival{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", location='" + location + '\'' +
                ", date=" + date +
                ", status=" + status +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }

    // Embedded Classes

    @Embeddable
    public static class VenueLayout {
        private int numberOfStages;
        private int vendorAreaCount;
        private boolean hasFacilities;

        public VenueLayout() {}

        public int getNumberOfStages() { return numberOfStages; }
        public void setNumberOfStages(int numberOfStages) { this.numberOfStages = numberOfStages; }

        public int getVendorAreaCount() { return vendorAreaCount; }
        public void setVendorAreaCount(int vendorAreaCount) { this.vendorAreaCount = vendorAreaCount; }

        public boolean isHasFacilities() { return hasFacilities; }
        public void setHasFacilities(boolean hasFacilities) { this.hasFacilities = hasFacilities; }
    }

    @Embeddable
    public static class Budget {
        private Double totalBudget;
        private Double performanceCosts;
        private Double logisticsCosts;
        private Double expectedRevenue;

        public Budget() {}

        public Double getTotalBudget() { return totalBudget; }
        public void setTotalBudget(Double totalBudget) { this.totalBudget = totalBudget; }

        public Double getPerformanceCosts() { return performanceCosts; }
        public void setPerformanceCosts(Double performanceCosts) { this.performanceCosts = performanceCosts; }

        public Double getLogisticsCosts() { return logisticsCosts; }
        public void setLogisticsCosts(Double logisticsCosts) { this.logisticsCosts = logisticsCosts; }

        public Double getExpectedRevenue() { return expectedRevenue; }
        public void setExpectedRevenue(Double expectedRevenue) { this.expectedRevenue = expectedRevenue; }
    }

    @Embeddable
    public static class VendorManagement {
        private int foodStalls;
        private int merchandiseBooths;

        public VendorManagement() {}

        public int getFoodStalls() { return foodStalls; }
        public void setFoodStalls(int foodStalls) { this.foodStalls = foodStalls; }

        public int getMerchandiseBooths() { return merchandiseBooths; }
        public void setMerchandiseBooths(int merchandiseBooths) { this.merchandiseBooths = merchandiseBooths; }
    }
}
