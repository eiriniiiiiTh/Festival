package com.festival.model;

public enum PerformanceStatus {
    CREATED,
    SUBMITTED,
    REVIEWED,
    APPROVED,
    REJECTED,
    SCHEDULED
}
