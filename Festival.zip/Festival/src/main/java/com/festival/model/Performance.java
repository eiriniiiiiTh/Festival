package com.festival.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "performances", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"name", "festival_id"})
})
public class Performance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @NotBlank
    @Size(min = 2, max = 100)
    @Column(nullable = false, length = 100)
    private String name;

    @NotBlank
    @Column(nullable = false)
    private String description;

    @NotBlank
    @Column(nullable = false)
    private String genre;

    @Min(1)
    @Column(nullable = false)
    private int duration;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "performance_artists",
        joinColumns = @JoinColumn(name = "performance_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    @JsonIgnoreProperties({"email", "password", "performances", "festivals"})
    private List<User> artists = new ArrayList<>();

    @NotBlank
    @Column(nullable = false)
    private String location;

    @FutureOrPresent
    @Column(nullable = false)
    private LocalDate date;

    @Lob
    private String technicalRequirements;

    @ElementCollection
    @CollectionTable(name = "performance_setlist", joinColumns = @JoinColumn(name = "performance_id"))
    @Column(name = "song")
    private List<String> setlist = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "performance_merchandise", joinColumns = @JoinColumn(name = "performance_id"))
    @Valid
    private List<MerchandiseItem> merchandiseItems = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "performance_rehearsal_times", joinColumns = @JoinColumn(name = "performance_id"))
    @Column(name = "time_slot")
    private List<String> preferredRehearsalTimes = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "performance_slots", joinColumns = @JoinColumn(name = "performance_id"))
    @Column(name = "slot")
    private List<String> preferredPerformanceSlots = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PerformanceStatus status = PerformanceStatus.CREATED;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "festival_id", nullable = false)
    @JsonIgnoreProperties(value = {"performances", "organizers", "staff"}, allowSetters = true)
    private Festival festival;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_staff_id")
    @JsonIgnoreProperties(value = {"email", "password", "performances", "festivals"}, allowSetters = true)
    private User assignedStaff;

    @Min(1)
    @Max(10)
    private Integer reviewScore;

    private String reviewComments;

    private String rejectionReason;

    @Embeddable
    public static class MerchandiseItem {

        @NotBlank
        private String name;

        @NotBlank
        private String description;

        @NotBlank
        private String type;

        @DecimalMin("0.0")
        private double price;

        public MerchandiseItem() {}

        public MerchandiseItem(String name, String description, String type, double price) {
            this.name = name;
            this.description = description;
            this.type = type;
            this.price = price;
        }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
    }

    public boolean isReadyForSubmission() {
        return technicalRequirements != null &&
               !setlist.isEmpty() &&
               !merchandiseItems.isEmpty() &&
               !preferredRehearsalTimes.isEmpty() &&
               !preferredPerformanceSlots.isEmpty() &&
               !artists.isEmpty();
    }

    public boolean isReviewed() {
        return reviewScore != null || (reviewComments != null && !reviewComments.isBlank());
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public List<User> getArtists() { return artists; }
    public void setArtists(List<User> artists) { this.artists = artists; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public String getTechnicalRequirements() { return technicalRequirements; }
    public void setTechnicalRequirements(String technicalRequirements) { this.technicalRequirements = technicalRequirements; }

    public List<String> getSetlist() { return setlist; }
    public void setSetlist(List<String> setlist) { this.setlist = setlist; }

    public List<MerchandiseItem> getMerchandiseItems() { return merchandiseItems; }
    public void setMerchandiseItems(List<MerchandiseItem> merchandiseItems) { this.merchandiseItems = merchandiseItems; }

    public List<String> getPreferredRehearsalTimes() { return preferredRehearsalTimes; }
    public void setPreferredRehearsalTimes(List<String> preferredRehearsalTimes) { this.preferredRehearsalTimes = preferredRehearsalTimes; }

    public List<String> getPreferredPerformanceSlots() { return preferredPerformanceSlots; }
    public void setPreferredPerformanceSlots(List<String> preferredPerformanceSlots) { this.preferredPerformanceSlots = preferredPerformanceSlots; }

    public PerformanceStatus getStatus() { return status; }
    public void setStatus(PerformanceStatus status) { this.status = status; }

    public Festival getFestival() { return festival; }
    public void setFestival(Festival festival) { this.festival = festival; }

    public User getAssignedStaff() { return assignedStaff; }
    public void setAssignedStaff(User assignedStaff) { this.assignedStaff = assignedStaff; }

    public Integer getReviewScore() { return reviewScore; }
    public void setReviewScore(Integer reviewScore) { this.reviewScore = reviewScore; }

    public String getReviewComments() { return reviewComments; }
    public void setReviewComments(String reviewComments) { this.reviewComments = reviewComments; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    @Override
    public String toString() {
        return "Performance{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", genre='" + genre + '\'' +
                ", duration=" + duration +
                ", status=" + status +
                ", createdAt=" + createdAt +
                '}';
    }
}
