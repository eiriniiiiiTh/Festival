package com.festival.repository;

import com.festival.model.Performance;
import com.festival.model.PerformanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PerformanceRepository extends JpaRepository<Performance, Long> {

    
    List<Performance> findByLocationContainingIgnoreCase(String location);

  
    List<Performance> findByStatus(PerformanceStatus status);

    
    List<Performance> findByDate(LocalDate date);

    
    List<Performance> findByDateAfter(LocalDate date);

    
    List<Performance> findByFestivalId(Long festivalId);

    List<Performance> findByStatusAndFestivalId(PerformanceStatus status, Long festivalId);

 
    List<Performance> findByNameContainingIgnoreCase(String name);

   
    List<Performance> findByGenreIgnoreCase(String genre);

   
    @Query("SELECT p FROM Performance p JOIN p.artists a WHERE LOWER(a.username) LIKE LOWER(CONCAT('%', :username, '%'))")
    List<Performance> findByArtistUsernameContainingIgnoreCase(@Param("username") String username);

    
    @Query("SELECT p FROM Performance p JOIN p.artists a WHERE LOWER(a.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Performance> findByArtistNameContainingIgnoreCase(@Param("name") String name);

    
    @Query("SELECT p FROM Performance p " +
           "WHERE (:name IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :name, '%'))) " +
           "AND (:location IS NULL OR LOWER(p.location) LIKE LOWER(CONCAT('%', :location, '%'))) " +
           "AND (:status IS NULL OR p.status = :status) " +
           "AND (:festivalId IS NULL OR p.festival.id = :festivalId) " +
           "AND (:date IS NULL OR p.date = :date)")
    List<Performance> searchWithFilters(@Param("name") String name,
                                        @Param("location") String location,
                                        @Param("status") PerformanceStatus status,
                                        @Param("festivalId") Long festivalId,
                                        @Param("date") LocalDate date);
}
