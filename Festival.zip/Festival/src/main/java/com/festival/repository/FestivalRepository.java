package com.festival.repository;

import com.festival.model.Festival;
import com.festival.model.FestivalStatus;
import com.festival.model.User;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface FestivalRepository extends JpaRepository<Festival, Long> {

    List<Festival> findByNameContainingIgnoreCase(String name);

    List<Festival> findByDescriptionContainingIgnoreCase(String description);

    List<Festival> findByLocationContainingIgnoreCase(String location);

    List<Festival> findByDate(LocalDate date);

    List<Festival> findByDateBetween(LocalDate startDate, LocalDate endDate);

    List<Festival> findByStatus(FestivalStatus status);

    List<Festival> findByOrganizersContaining(User organizer);

    @Query("SELECT f FROM Festival f " +
           "WHERE (:name IS NULL OR LOWER(f.name) LIKE LOWER(CONCAT('%', :name, '%'))) " +
           "AND (:description IS NULL OR LOWER(f.description) LIKE LOWER(CONCAT('%', :description, '%'))) " +
           "AND (:location IS NULL OR LOWER(f.location) LIKE LOWER(CONCAT('%', :location, '%'))) " +
           "AND (:startDate IS NULL OR f.date >= :startDate) " +
           "AND (:endDate IS NULL OR f.date <= :endDate) " +
           "AND (:status IS NULL OR f.status = :status)")
    List<Festival> searchFestivals(@Param("name") String name,
                                   @Param("description") String description,
                                   @Param("location") String location,
                                   @Param("startDate") LocalDate startDate,
                                   @Param("endDate") LocalDate endDate,
                                   @Param("status") FestivalStatus status);

    List<Festival> findAll(Sort sort);
}
