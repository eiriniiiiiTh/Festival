package com.festival.controller;

import com.festival.model.User;
import com.festival.model.UserRole;
import com.festival.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users") // Βασική διαδρομή για όλα τα endpoints χρηστών
public class UserController {

    private final UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    // Ανάκτηση όλων των χρηστών ή φιλτράρισμα με βάση id, username, email, name ή role
    // URL: GET http://localhost:8080/users?username=...&email=...&name=...&role=...
    @GetMapping
    public ResponseEntity<?> getUsers(
            @RequestParam(required = false) Long id,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) UserRole role) {

        try {
            if (id != null) {
                return ResponseEntity.ok(service.getUserById(id));
            }

            if (username != null) {
                return ResponseEntity.ok(service.getUserByUsername(username));
            }

            if (email != null) {
                return ResponseEntity.ok(service.getUserByEmail(email));
            }

            if (name != null) {
                return ResponseEntity.ok(service.searchByName(name));
            }

            if (role != null) {
                return ResponseEntity.ok(service.getUsersByRole(role));
            }

            return ResponseEntity.ok(service.getAllUsers());

        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body("User not found");
        }
    }

    // Ανάκτηση χρήστη με βάση το ID
    // URL: GET http://localhost:8080/users/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(service.getUserById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body("User not found");
        }
    }

    // Δημιουργία νέου χρήστη
    // URL: POST http://localhost:8080/users
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody @Valid User user) {
        return ResponseEntity.ok(service.createUser(user));
    }

    // Ενημέρωση χρήστη με βάση το ID
    // URL: PUT http://localhost:8080/users/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id,
                                        @RequestBody @Valid User user) {
        if (!service.existsById(id)) {
            return ResponseEntity.status(404).body("User not found");
        }
        return ResponseEntity.ok(service.updateUser(id, user));
    }

    // Διαγραφή χρήστη με βάση το ID
    // URL: DELETE http://localhost:8080/users/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        if (!service.existsById(id)) {
            return ResponseEntity.status(404).body("User not found");
        }
        service.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    // Login χρήστη (απλός έλεγχος credentials χωρίς χρήση JWT)
    // URL: POST http://localhost:8080/users/login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User loginUser) {
        boolean success = service.authenticateUser(loginUser.getUsername(), loginUser.getPassword());
        return success
                ? ResponseEntity.ok("Login successful")
                : ResponseEntity.status(401).body("Invalid credentials");
    }
}
