package com.festival.controller;

import com.festival.model.Festival;
import com.festival.model.FestivalStatus;
import com.festival.service.FestivalService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/festivals")
public class FestivalController {

    private final FestivalService festivalService;

    @Autowired
    public FestivalController(FestivalService festivalService) {
        this.festivalService = festivalService;
    }

    // Δημιουργία νέου φεστιβάλ
    // URL: POST http://localhost:8080/festivals
    @PostMapping
    public ResponseEntity<Festival> createFestival(@RequestBody @Valid Festival festival) {
        Festival created = festivalService.createFestival(festival);
        return ResponseEntity.ok(created);
    }

    // Ανάκτηση όλων των φεστιβάλ ή φιλτραρισμένων βάσει name, location ή status
    // URL: GET http://localhost:8080/festivals?name=...&location=...&status=...
    @GetMapping
    public ResponseEntity<List<Festival>> getFestivals(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) FestivalStatus status) {

        if (name != null) {
            return ResponseEntity.ok(festivalService.searchByName(name));
        } else if (location != null) {
            return ResponseEntity.ok(festivalService.searchByLocation(location));
        } else if (status != null) {
            return ResponseEntity.ok(festivalService.getFestivalsByStatus(status));
        } else {
            return ResponseEntity.ok(festivalService.getAllFestivals());
        }
    }

    // Ανάκτηση φεστιβάλ με βάση το ID
    // URL: GET http://localhost:8080/festivals/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Festival> getFestivalById(@PathVariable Long id) {
        Festival festival = festivalService.getFestivalById(id);
        return ResponseEntity.ok(festival);
    }

    // Ενημέρωση στοιχείων φεστιβάλ
    // URL: PUT http://localhost:8080/festivals/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Festival> updateFestival(@PathVariable Long id,
                                                   @RequestBody @Valid Festival festival) {
        Festival updated = festivalService.updateFestival(id, festival);
        return ResponseEntity.ok(updated);
    }

    // Διαγραφή φεστιβάλ
    // URL: DELETE http://localhost:8080/festivals/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFestival(@PathVariable Long id) {
        festivalService.deleteFestival(id);
        return ResponseEntity.noContent().build();
    }

    // Αλλαγή κατάστασης φεστιβάλ (π.χ. από CREATED σε APPROVED)
    // URL: PATCH http://localhost:8080/festivals/{id}/status?status=APPROVED
    @PatchMapping("/{id}/status")
    public ResponseEntity<Festival> changeStatus(@PathVariable Long id,
                                                 @RequestParam FestivalStatus status) {
        if (status == null) {
            return ResponseEntity.badRequest().build();
        }
        Festival updated = festivalService.changeFestivalStatus(id, status);
        return ResponseEntity.ok(updated);
    }
}
