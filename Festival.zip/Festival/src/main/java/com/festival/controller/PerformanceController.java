package com.festival.controller;

import com.festival.model.Performance;
import com.festival.model.PerformanceStatus;
import com.festival.service.PerformanceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/performances") // Βασική διαδρομή για όλα τα endpoints εμφάνισης
public class PerformanceController {

    private final PerformanceService service;

    @Autowired
    public PerformanceController(PerformanceService service) {
        this.service = service;
    }

    // Ανάκτηση όλων των εμφανίσεων ή φιλτραρισμένων βάσει name, genre, artistUsername, festivalId ή status
    // URL: GET http://localhost:8080/performances?name=...&genre=...&artistUsername=...&festivalId=...&status=...
    @GetMapping
    public ResponseEntity<List<Performance>> getPerformances(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) String artistUsername,
            @RequestParam(required = false) Long festivalId,
            @RequestParam(required = false) PerformanceStatus status) {

        return ResponseEntity.ok(service.searchPerformances(name, genre, artistUsername, festivalId, status));
    }

    // Ανάκτηση εμφάνισης με βάση το ID
    // URL: GET http://localhost:8080/performances/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Performance> getById(@PathVariable Long id) {
        return service.getPerformanceById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Δημιουργία νέας εμφάνισης
    // URL: POST http://localhost:8080/performances
    @PostMapping
    public ResponseEntity<?> create(@RequestBody @Valid Performance performance) {
        try {
            if (performance.getFestival() == null || performance.getAssignedStaff() == null) {
                return ResponseEntity.badRequest().body("Festival and assigned staff are required.");
            }
            Performance created = service.createPerformance(performance);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Σφάλμα κατά τη δημιουργία performance: " + e.getMessage());
        }
    }

    // Ενημέρωση εμφάνισης με βάση το ID
    // URL: PUT http://localhost:8080/performances/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,
                                    @RequestBody @Valid Performance performance) {
        if (!service.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        try {
            Performance updated = service.updatePerformance(id, performance);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Σφάλμα κατά την ενημέρωση performance: " + e.getMessage());
        }
    }

    // Διαγραφή εμφάνισης με βάση το ID (μόνο αν είναι σε κατάσταση CREATED)
    // URL: DELETE http://localhost:8080/performances/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (!service.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        try {
            service.deletePerformance(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Σφάλμα κατά τη διαγραφή performance: " + e.getMessage());
        }
    }

    // Αλλαγή κατάστασης εμφάνισης (π.χ. από CREATED σε SUBMITTED)
    // URL: PATCH http://localhost:8080/performances/{id}/status?status=SUBMITTED
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> changeStatus(@PathVariable Long id,
                                          @RequestParam PerformanceStatus status) {
        if (!service.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        if (status == null) {
            return ResponseEntity.badRequest().body("Status is required.");
        }
        try {
            Performance updated = service.changePerformanceStatus(id, status);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Σφάλμα κατά την αλλαγή status: " + e.getMessage());
        }
    }

    // Χειρισμός σφαλμάτων επικύρωσης (validation errors)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationError(MethodArgumentNotValidException ex) {
        StringBuilder sb = new StringBuilder("Validation failed:\n");
        ex.getBindingResult().getFieldErrors().forEach(error ->
                sb.append("- ").append(error.getField()).append(": ").append(error.getDefaultMessage()).append("\n"));
        return ResponseEntity.badRequest().body(sb.toString());
    }
}
