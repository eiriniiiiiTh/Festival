package com.festival.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// Δηλώνει ότι όταν πετάγεται αυτή η εξαίρεση, η HTTP απόκριση θα έχει status code 404 (NOT_FOUND)
@ResponseStatus(HttpStatus.NOT_FOUND)
public class PerformanceNotFoundException extends RuntimeException {

    // Κατασκευαστής που δέχεται το ID της εμφάνισης και δημιουργεί μήνυμα σφάλματος
    public PerformanceNotFoundException(Long id) {
        super("Performance with ID " + id + " not found.");
    }
}
