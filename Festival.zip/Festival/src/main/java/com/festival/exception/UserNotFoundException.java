package com.festival.exception;

// Εξαίρεση που πετάγεται όταν δεν εντοπίζεται χρήστης στη βάση
public class UserNotFoundException extends RuntimeException {

    // Κατασκευαστής για αναζήτηση χρήστη με βάση το ID
    public UserNotFoundException(Long id) {
        super("User with ID " + id + " not found.");
    }

    // Κατασκευαστής για αναζήτηση χρήστη με βάση το username ή το email
    public UserNotFoundException(String message) {
        super(message);
    }
}
